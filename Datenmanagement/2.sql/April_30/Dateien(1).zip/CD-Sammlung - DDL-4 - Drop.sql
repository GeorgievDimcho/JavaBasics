/*------------------------------------------------
Tabellen löschen
------------------------------------------------*/

-- bei Verwendung der CASCADE CONSTRAINTS Klausel muss beim Löschen von Tabellen nicht auf die richtige Reihenfolge geachtet werden
-- CASCADE CONSTRAINTS bewirkt, dass bestehende FK Constraints in anderen Tabellen automatisch mitgelöscht werden
DROP TABLE Verlag CASCADE CONSTRAINTS;
DROP TABLE Ort CASCADE CONSTRAINTS;
DROP TABLE CD CASCADE CONSTRAINTS;
DROP TABLE Urheber CASCADE CONSTRAINTS;
DROP TABLE Rolle CASCADE CONSTRAINTS;
DROP TABLE Urheberschaft CASCADE CONSTRAINTS;


-- ohne CASCADE CONSTRAINTS müssen die Tabellen in der richtigen Reihenfolge gelöscht werden.
DROP TABLE Urheberschaft;
DROP TABLE Rolle;
DROP TABLE Urheber;
DROP TABLE CD;
DROP TABLE Verlag;
DROP TABLE Ort;
