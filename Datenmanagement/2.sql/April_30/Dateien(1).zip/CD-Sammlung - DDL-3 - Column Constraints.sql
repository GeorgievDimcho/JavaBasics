/*------------------------------------------------
Tabellen mit Foreign Keys erstellen
Sie können bei der Erstellung der Tabellen auch gleich die Constraints für die Fremdschlüssel einfügen.
In diesem Beispiel werden die Foreign Key Constraints als Column Constraint (inline) ohne Namen angegeben. 
------------------------------------------------*/

-- Tabelle Ort
CREATE TABLE Ort (
	PLZ integer primary key,
	Ortsname varchar2(50) not null); -- NOT NULL muss als Column Constraint (inline) definiert werden

-- Tabelle Verlag
CREATE TABLE Verlag (
	VID integer primary key,
	Name varchar2(50) not null,
	Straße varchar2(50),
	Nummer varchar2(10),
	PLZ integer REFERENCES ORT (PLZ)); -- FK Column Constraint (inline) ohne definierten Namen (=> System vergibt internen Namen) 

-- Tabelle CD
CREATE TABLE CD (
	CID integer primary key,
	Titel varchar2(50) not null,
	Erscheinungsjahr integer,
	VID integer REFERENCES Verlag (VID);

-- Tabelle Urheber
CREATE TABLE Urheber (
	"UID" integer primary key, -- in Oracle ist UID eine Funktion, die die ID des angemeldeten Benzutzers zurück gibt
	Name varchar2(50) not null,
	Vorname varchar2(50),
	Heimatland varchar2(50));

-- Tabelle Rolle
CREATE TABLE Rolle (
	RID integer primary key,
	Bezeichnung varchar2(50) not null unique);

-- Tabelle Urheberschaft
CREATE TABLE Urheberschaft (
	CID integer REFERENCES CD (CID) ON DELETE CASCADE, 
	RID integer REFERENCES Rolle (RID) ON DELETE SET NULL,
	"UID" integer REFERENCES Urheber ("UID") ON DELETE SET NULL,
	primary key (CID, RID, "UID")); -- zusammengesetzte Schlüssel müssen als Table Constraint (outline) definiert werden

