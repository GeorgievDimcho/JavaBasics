/*------------------------------------------------
Tabellen ohne Foreign Keys erstellen
Werden die Tabellen zunächst ohne Definition der Fremdschlüssel erstellt, 
müssen Sie nicht auf die Reihenfolge, in der Sie die Tabellen erstellen, achten.
------------------------------------------------*/

-- Tabelle Verlag
CREATE TABLE Verlag (
	VID integer primary key,
	Name varchar2(50) not null, -- NOT NULL Constraints müssen als Column Constraint (inline) definiert werden
	Straße varchar2(50),
	Nummer varchar2(10),
	PLZ integer);

-- Tabelle Ort
CREATE TABLE Ort (
	PLZ integer primary key,
	Ortsname varchar2(50) not null);

-- Tabelle CD
CREATE TABLE CD (
	CID integer primary key,
	Titel varchar2(50) not null,
	Erscheinungsjahr integer,
	VID integer);

-- Tabelle Urheber
CREATE TABLE Urheber (
	"UID" integer primary key,
	Name varchar2(50) not null,
	Vorname varchar2(50),
	Heimatland varchar2(50));

-- Tabelle Urheber
CREATE TABLE Rolle (
	RID integer primary key,
	Bezeichnung varchar2(50) not null unique);

-- Tabelle Urheberschaft
CREATE TABLE Urheberschaft (
	CID integer,
	RID integer,
	"UID" integer,
	primary key (CID, RID, "UID")); -- zusammengesetze Schlüssel müssen als Table Constraint (outline) definiert werden




/*------------------------------------------------
Foreign Keys erstellen
Nachdem die Tabellen angelegt wurden, müssen Sie mit dem ALTER TABLE Befehl 
die Constraints für die Fremdschlüssel anlegen.
------------------------------------------------*/
ALTER TABLE Verlag
	ADD CONSTRAINT FK_Verlag_PLZ FOREIGN KEY (PLZ) 
		REFERENCES ORT (PLZ);
		
ALTER TABLE CD
	ADD CONSTRAINT FK_CD_VID FOREIGN KEY (VID) 
		REFERENCES Verlag (VID);
		
ALTER TABLE Urheberschaft 
	ADD (
		CONSTRAINT FK_UHS_CID 
			FOREIGN KEY (CID) REFERENCES CD (CID) ON DELETE CASCADE,
		CONSTRAINT FK_UHS_UID 
			FOREIGN KEY ("UID") REFERENCES Urheber ("UID") ON DELETE SET NULL,
		CONSTRAINT FK_UHS_RID 
			FOREIGN KEY (RID) REFERENCES Rolle (RID) ON DELETE SET NULL
		);
