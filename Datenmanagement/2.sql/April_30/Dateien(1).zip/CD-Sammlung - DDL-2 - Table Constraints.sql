/*------------------------------------------------
Tabellen mit Foreign Keys erstellen
Sie können bei der Erstellung der Tabellen auch gleich die Constraints für die Fremdschlüssel einfügen.
In diesem Beispiel werden die Foreign Key Constraints als Table Constraint (outline) angegeben. 
Das heißt, zuerst werden alle Attribute definiert und anlschließend folgen die entsprechende Anweisung zum Anlegen des Foreign Keys.
Über das Schlüsselwort CONSTRAINT kann einem Constraint auch eine Name zugewiesen werden. 
------------------------------------------------*/

-- Tabelle Ort
CREATE TABLE Ort (
	PLZ integer primary key,
	Ortsname varchar2(50) not null); -- NOT NULL muss als Column Constraint (inline) definiert werden

-- Tabelle Verlag
CREATE TABLE Verlag (
	VID integer primary key,
	Name varchar2(50) not null,
	Straße varchar2(50),
	Nummer varchar2(10),
	PLZ integer,
	-- FKs als Table Constraints (outline)
	CONSTRAINT FK_Verlag_PLZ -- hier wird der Name "FK_Verlag_PLZ" für den FK Constraint festgelet
		FOREIGN KEY (PLZ) REFERENCES ORT (PLZ)); -- hier wird der FK definiert

-- Tabelle CD
CREATE TABLE CD (
	CID integer primary key,
	Titel varchar2(50) not null,
	Erscheinungsjahr integer,
	VID integer,
	 CONSTRAINT FK_CD_VID 
		FOREIGN KEY (VID) REFERENCES Verlag (VID));

-- Tabelle Urheber
CREATE TABLE Urheber (
	"UID" integer primary key,
	Name varchar2(50) not null,
	Vorname varchar2(50),
	Heimatland varchar2(50));

-- Tabelle Rolle
CREATE TABLE Rolle (
	RID integer primary key,
	Bezeichnung varchar2(50) not null unique);

-- Tabelle Urheberschaft
CREATE TABLE Urheberschaft (
	CID integer,
	RID integer,
	"UID" integer,
	primary key (CID, RID, "UID"), -- zusammengesetzte Schlüssel müssen als Table Constraint (outline) definiert werden
	CONSTRAINT FK_UHS_CID 
		FOREIGN KEY (CID) REFERENCES CD (CID) 
			ON DELETE CASCADE, -- wird der referenzierte Datensatz gelöscht, wird auch jeder verbundene Datensatz in dieser Tabelle gelöscht
	CONSTRAINT FK_UHS_UID 
		FOREIGN KEY ("UID") REFERENCES Urheber ("UID") 
			ON DELETE SET NULL, -- wird der referenzierte Datensatz gelöscht, wird der Wert des FK jedes verbundenen Datensatzes auf NULL gesetzt
	CONSTRAINT FK_UHS_RID 
		FOREIGN KEY (RID) REFERENCES Rolle (RID) 
			ON DELETE SET NULL);

