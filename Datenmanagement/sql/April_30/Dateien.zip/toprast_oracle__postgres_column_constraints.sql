-- -----------------------------------------------------
-- Schema toprast
-- -----------------------------------------------------
DROP TABLE allerg_prod ;
DROP TABLE allergene ;
DROP TABLE rechn_prod ;
DROP TABLE produkte ;
DROP TABLE rechnungen ;
DROP TABLE filialen ;
DROP TABLE kunden ;
DROP TABLE mitarbeiter ;
DROP TABLE personen ;
DROP TABLE adressen ;
DROP TABLE orte ;


-- -----------------------------------------------------
-- Table orte
-- -----------------------------------------------------

CREATE TABLE orte (
  plz INT PRIMARY KEY NOT NULL 
	CONSTRAINT ck_plz 
	  CHECK (plz between 1000 and 9999),
  ort VARCHAR(64) NOT NULL )
;


-- -----------------------------------------------------
-- Table adressen
-- -----------------------------------------------------

CREATE TABLE adressen (
  addr_id INT PRIMARY KEY NOT NULL,
  strasse VARCHAR(64) NOT NULL,
  hausnummer VARCHAR(10) NULL,
  plz int NOT NULL
	CONSTRAINT fk_plz 
	  REFERENCES orte (plz))
;


-- -----------------------------------------------------
-- Table personen
-- -----------------------------------------------------

CREATE TABLE personen (
  pers_id INT PRIMARY KEY NOT NULL,
  vorname VARCHAR(45) NULL,
  nachname VARCHAR(45) NULL,
  geschlecht CHAR(1) 
    CONSTRAINT ck_personen_geschlecht 
	    CHECK (geschlecht IN('m','w')),
  fk_addr_id INT 
    CONSTRAINT fk_personen_adressen
      REFERENCES adressen (addr_id)
        ON DELETE SET NULL)
;


-- -----------------------------------------------------
-- Table kunden
-- -----------------------------------------------------

CREATE TABLE kunden (
  fk_pers_id INT PRIMARY KEY NOT NULL 
    CONSTRAINT fk_kunden_personen
      REFERENCES personen (pers_id)
        ON DELETE CASCADE,
  kundennummer INT UNIQUE NOT NULL
  )
;


-- -----------------------------------------------------
-- Table filialen
-- -----------------------------------------------------

CREATE TABLE filialen (
  f_id INT PRIMARY KEY NOT NULL,
  "uid" VARCHAR(12) NULL,
  name VARCHAR(45) NOT NULL,
  telefon VARCHAR(45) NULL,
  fax VARCHAR(45) NULL,
  fk_addr_id INT NOT NULL 
    CONSTRAINT fk_filialen_adressen
      REFERENCES adressen (addr_id),
  geschlossen CHAR(1) DEFAULT 0 NOT NULL 
    CONSTRAINT ck_filialen_geschlossen 
      CHECK (CAST(geschlossen AS INT) IN (0,1)))
;


-- -----------------------------------------------------
-- Table mitarbeiter
-- -----------------------------------------------------

CREATE TABLE mitarbeiter (
  fk_pers_id INT PRIMARY KEY NOT NULL 
    CONSTRAINT fk_mitarbeiter_personen
      REFERENCES personen (pers_id),
  mitarbeiternummer INT UNIQUE NOT NULL,
  svn INT NOT NULL 
    CONSTRAINT ck_mitarbeiter_svn 
      CHECK (svn BETWEEN 1000 AND 9999),
  geburtsdatum DATE NOT NULL,
  eintrittsdatum DATE NOT NULL,
  austrittsdatum DATE NULL)
;


-- -----------------------------------------------------
-- Table rechnungen
-- -----------------------------------------------------

CREATE TABLE rechnungen (
  rechn_nr INT PRIMARY KEY NOT NULL,
  datum DATE NOT NULL,
  zeit TIMESTAMP NOT NULL,
  fk_f_id INT NOT NULL 
    CONSTRAINT fk_rechnungen_filialen
      REFERENCES filialen (f_id),
  fk_kunden_pers_id INT NULL 
    CONSTRAINT fk_rechnungen_kunden
      REFERENCES kunden (fk_pers_id)
        ON DELETE SET NULL,
  fk_mitarbeiter_pers_id INT NULL 
    CONSTRAINT fk_rechnungen_mitarbeiter
      REFERENCES mitarbeiter (fk_pers_id)
        ON DELETE SET NULL)
;


-- -----------------------------------------------------
-- Table produkte
-- -----------------------------------------------------

CREATE TABLE produkte (
  produkt_id INT PRIMARY KEY NOT NULL,
  name VARCHAR(64) NOT NULL,
  preis REAL NOT NULL,
  mwst REAL NOT NULL,
  ausgelaufen CHAR(1) DEFAULT 0 NOT NULL 
    CONSTRAINT ck_produkte_ausgelaufen 
      CHECK (CAST(ausgelaufen AS INT) IN (0,1)))
;


-- -----------------------------------------------------
-- Table rechn_prod
-- -----------------------------------------------------

CREATE TABLE rechn_prod (
  id INT PRIMARY KEY NOT NULL,
  preis REAL NOT NULL,
  mwst REAL NOT NULL,
  fk_prod_id INT NULL 
    CONSTRAINT fk_rechn_prod_produkte
      REFERENCES produkte (produkt_id)
        ON DELETE SET NULL,
  fk_rechn_nr INT NOT NULL 
    CONSTRAINT fk_rechn_prod_rechnungen
      REFERENCES rechnungen (rechn_nr)
        ON DELETE CASCADE)
;


-- -----------------------------------------------------
-- Table allergene
-- -----------------------------------------------------

CREATE TABLE allergene (
  kuerzel CHAR(1) PRIMARY KEY NOT NULL 
    CONSTRAINT ck_allergene_kuerzel 
  	  CHECK (kuerzel in ('A','B','C','D','E','F','G','H','L','M','N','O','P','R')),
  bezeichnung VARCHAR(64) NOT NULL)
;


-- -----------------------------------------------------
-- Table allerg_prod
-- -----------------------------------------------------

CREATE TABLE allerg_prod (
  fk_kuerzel CHAR(1) NOT NULL 
    CONSTRAINT fk_allerg_prod_allergene
      REFERENCES allergene (kuerzel)
        ON DELETE CASCADE,
  fk_produkt_id INT NOT NULL 
    CONSTRAINT fk_allerg_prod_produkte
      REFERENCES produkte (produkt_id)
        ON DELETE CASCADE,
  PRIMARY KEY (fk_kuerzel, fk_produkt_id))
;



