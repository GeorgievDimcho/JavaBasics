-- -----------------------------------------------------
-- Schema toprast
-- -----------------------------------------------------
DROP TABLE allerg_prod ;
DROP TABLE allergene ;
DROP TABLE rechn_prod ;
DROP TABLE produkte ;
DROP TABLE rechnungen ;
DROP TABLE filialen ;
DROP TABLE kunden ;
DROP TABLE mitarbeiter ;
DROP TABLE personen ;
DROP TABLE adressen ;
DROP TABLE orte ;



-- -----------------------------------------------------
-- Create Tables 
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Table orte
-- -----------------------------------------------------

CREATE TABLE orte (
  plz INT NOT NULL,
  ort VARCHAR(64) NOT NULL,
  PRIMARY KEY (plz),
  CONSTRAINT ck_plz 
	CHECK (plz between 1000 and 9999))
;


-- -----------------------------------------------------
-- Table adressen
-- -----------------------------------------------------

CREATE TABLE adressen (
  addr_id INT NOT NULL,
  strasse VARCHAR(64) NOT NULL,
  hausnummer VARCHAR(10) NULL,
  plz int NOT NULL,
  PRIMARY KEY (addr_id))
;


-- -----------------------------------------------------
-- Table personen
-- -----------------------------------------------------

CREATE TABLE personen (
  pers_id INT PRIMARY KEY NOT NULL,
  vorname VARCHAR(45) NULL,
  nachname VARCHAR(45) NULL,
  geschlecht CHAR(1) 
    CONSTRAINT ck_personen_geschlecht 
	    CHECK (geschlecht IN('m','w')),
  fk_addr_id INT)
;


-- -----------------------------------------------------
-- Table kunden
-- -----------------------------------------------------

CREATE TABLE kunden (
  fk_pers_id INT NOT NULL,
  kundennummer INT UNIQUE NOT NULL,
  PRIMARY KEY (fk_pers_id))
;


-- -----------------------------------------------------
-- Table filialen
-- -----------------------------------------------------

CREATE TABLE filialen (
  f_id INT NOT NULL,
  "uid" VARCHAR(12) NULL,
  name VARCHAR(45) NOT NULL,
  telefon VARCHAR(45) NULL,
  fax VARCHAR(45) NULL,
  fk_addr_id INT NOT NULL,
  geschlossen CHAR(1) DEFAULT 0 NOT NULL,
  PRIMARY KEY (f_id),
  CONSTRAINT ck_filialen_geschlossen 
    CHECK (CAST(geschlossen AS INT) IN (0,1)))
;


-- -----------------------------------------------------
-- Table mitarbeiter
-- -----------------------------------------------------

CREATE TABLE mitarbeiter (
  fk_pers_id INT NOT NULL,
  mitarbeiternummer INT UNIQUE NOT NULL,
  svn INT NOT NULL,
  geburtsdatum DATE NOT NULL,
  eintrittsdatum DATE NOT NULL,
  austrittsdatum DATE NULL,
  PRIMARY KEY (fk_pers_id),
  CONSTRAINT ck_mitarbeiter_svn 
    CHECK (svn BETWEEN 1000 AND 9999))
;


-- -----------------------------------------------------
-- Table rechnungen
-- -----------------------------------------------------

CREATE TABLE rechnungen (
  rechn_nr INT NOT NULL,
  datum DATE NOT NULL,
  zeit TIMESTAMP NOT NULL,
  fk_f_id INT NOT NULL,
  fk_kunden_pers_id INT NULL,
  fk_mitarbeiter_pers_id INT NULL,
  PRIMARY KEY (rechn_nr))
;


-- -----------------------------------------------------
-- Table produkte
-- -----------------------------------------------------

CREATE TABLE produkte (
  produkt_id INT NOT NULL,
  name VARCHAR(64) NOT NULL,
  preis REAL NOT NULL,
  mwst REAL NOT NULL,
  ausgelaufen CHAR(1) DEFAULT 0 NOT NULL,
  PRIMARY KEY (produkt_id),
  CONSTRAINT ck_produkte_ausgelaufen 
    CHECK (CAST(ausgelaufen AS INT) IN (0,1)))
;


-- -----------------------------------------------------
-- Table rechn_prod
-- -----------------------------------------------------

CREATE TABLE rechn_prod (
  id INT NOT NULL,
  preis REAL NOT NULL,
  mwst REAL NOT NULL,
  fk_prod_id INT NULL,
  fk_rechn_nr INT NOT NULL,
  PRIMARY KEY (id))
;


-- -----------------------------------------------------
-- Table allergene
-- -----------------------------------------------------

CREATE TABLE allergene (
  kuerzel CHAR(1) NOT NULL,
  bezeichnung VARCHAR(64) NOT NULL,
  PRIMARY KEY (kuerzel),
  CONSTRAINT ck_allergene_kuerzel 
	  CHECK (kuerzel in ('A','B','C','D','E','F','G','H','L','M','N','O','P','R')))
;


-- -----------------------------------------------------
-- Table allerg_prod
-- -----------------------------------------------------

CREATE TABLE allerg_prod (
  fk_kuerzel CHAR(1) NOT NULL,
  fk_produkt_id INT NOT NULL,
  PRIMARY KEY (fk_kuerzel, fk_produkt_id))
;





-- -----------------------------------------------------
-- Alter Tables 
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Alter Table adressen
-- -----------------------------------------------------

ALTER TABLE adressen 
  ADD CONSTRAINT fk_plz 
		FOREIGN KEY (plz) 
		  REFERENCES orte (plz);


-- -----------------------------------------------------
-- Alter Table personen
-- -----------------------------------------------------

ALTER TABLE personen
  ADD CONSTRAINT fk_personen_adressen
        FOREIGN KEY (fk_addr_id)
          REFERENCES adressen (addr_id)
            ON DELETE SET NULL;


-- -----------------------------------------------------
-- Alter Table kunden
-- -----------------------------------------------------

ALTER TABLE kunden 
  ADD CONSTRAINT fk_kunden_personen
        FOREIGN KEY (fk_pers_id)
          REFERENCES personen (pers_id)
            ON DELETE CASCADE;
            

-- -----------------------------------------------------
-- Alter Table filialen
-- -----------------------------------------------------

ALTER TABLE filialen 
  ADD CONSTRAINT fk_filialen_adressen
        FOREIGN KEY (fk_addr_id)
          REFERENCES adressen (addr_id);
          

-- -----------------------------------------------------
-- Alter Table mitarbeiter
-- -----------------------------------------------------

ALTER TABLE mitarbeiter 
  ADD CONSTRAINT fk_mitarbeiter_personen
        FOREIGN KEY (fk_pers_id)
          REFERENCES personen (pers_id);


-- -----------------------------------------------------
-- Alter Table rechnungen
-- -----------------------------------------------------

ALTER TABLE rechnungen 
  ADD CONSTRAINT fk_rechnungen_filialen
        FOREIGN KEY (fk_f_id)
          REFERENCES filialen (f_id);
		  
ALTER TABLE rechnungen 
  ADD CONSTRAINT fk_rechnungen_kunden
        FOREIGN KEY (fk_kunden_pers_id)
          REFERENCES kunden (fk_pers_id)
            ON DELETE SET NULL;

ALTER TABLE rechnungen 
  ADD CONSTRAINT fk_rechnungen_mitarbeiter
      FOREIGN KEY (fk_mitarbeiter_pers_id)
        REFERENCES mitarbeiter (fk_pers_id)
          ON DELETE SET NULL;


-- -----------------------------------------------------
-- Alter Table rechn_prod
-- -----------------------------------------------------

ALTER TABLE rechn_prod 
  ADD CONSTRAINT fk_rechn_prod_rechnungen
        FOREIGN KEY (fk_rechn_nr)
          REFERENCES rechnungen (rechn_nr)
            ON DELETE CASCADE;

ALTER TABLE rechn_prod 
  ADD CONSTRAINT fk_rechn_prod_produkte
        FOREIGN KEY (fk_prod_id)
          REFERENCES produkte (produkt_id)
            ON DELETE SET NULL;


-- -----------------------------------------------------
-- Alter Table allerg_prod
-- -----------------------------------------------------

ALTER TABLE allerg_prod 
  ADD CONSTRAINT fk_allerg_prod_allergene
        FOREIGN KEY (fk_kuerzel)
          REFERENCES allergene (kuerzel)
            ON DELETE CASCADE;

ALTER TABLE allerg_prod 
  ADD CONSTRAINT fk_allerg_prod_produkte
        FOREIGN KEY (fk_produkt_id)
          REFERENCES produkte (produkt_id)
            ON DELETE CASCADE;




