-- -----------------------------------------------------
-- Schema toprast
-- -----------------------------------------------------
DROP TABLE IF EXISTS allerg_prod ;
DROP TABLE IF EXISTS allergene ;
DROP TABLE IF EXISTS rechn_prod ;
DROP TABLE IF EXISTS produkte ;
DROP TABLE IF EXISTS rechnungen ;
DROP TABLE IF EXISTS filialen ;
DROP TABLE IF EXISTS kunden ;
DROP TABLE IF EXISTS mitarbeiter ;
DROP TABLE IF EXISTS personen ;
DROP TABLE IF EXISTS adressen ;
DROP TABLE IF EXISTS orte ;


-- -----------------------------------------------------
-- Table orte
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS orte (
  plz INT NOT NULL,
  ort VARCHAR(64) NOT NULL,
  PRIMARY KEY (plz),
  CONSTRAINT ck_plz 
	CHECK (plz between 1000 and 9999))
;


-- -----------------------------------------------------
-- Table adressen
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS adressen (
  addr_id SERIAL NOT NULL,
  strasse VARCHAR(64) NOT NULL,
  plz int NOT NULL,
  hausnummer VARCHAR(10) NULL,
  PRIMARY KEY (addr_id),
  CONSTRAINT fk_plz 
	FOREIGN KEY (plz) 
	REFERENCES orte (plz))
;


-- -----------------------------------------------------
-- Table personen
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS personen (
  pers_id SERIAL NOT NULL,
  vorname VARCHAR(45) NULL,
  nachname VARCHAR(45) NULL,
  geschlecht CHAR(1),
  fk_addr_id INT NULL,
  PRIMARY KEY (pers_id),
  CONSTRAINT ck_personen_geschlecht
    CHECK (geschlecht IN('m','w')),
  CONSTRAINT fk_personen_adressen
    FOREIGN KEY (fk_addr_id)
    REFERENCES adressen (addr_id)
    ON DELETE SET NULL
    ON UPDATE SET NULL)
;


-- -----------------------------------------------------
-- Table kunden
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS kunden (
  fk_pers_id INT NOT NULL,
  kundennummer INT UNIQUE NOT NULL,
  PRIMARY KEY (fk_pers_id),
  CONSTRAINT fk_kunden_personen
    FOREIGN KEY (fk_pers_id)
    REFERENCES personen (pers_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
;


-- -----------------------------------------------------
-- Table filialen
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS filialen (
  f_id SERIAL NOT NULL,
  uid VARCHAR(12) NULL,
  name VARCHAR(45) NOT NULL,
  telefon VARCHAR(45) NULL,
  fax VARCHAR(45) NULL,
  fk_addr_id INT NOT NULL,
  geschlossen BOOLEAN NOT NULL DEFAULT FALSE,
  PRIMARY KEY (f_id),
  CONSTRAINT fk_filialen_adressen
    FOREIGN KEY (fk_addr_id)
    REFERENCES adressen (addr_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
;


-- -----------------------------------------------------
-- Table mitarbeiter
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS mitarbeiter (
  fk_pers_id INT NOT NULL,
  mitarbeiternummer INT UNIQUE NOT NULL,
  svn INT NOT NULL,
  geburtsdatum DATE NOT NULL,
  eintrittsdatum DATE NOT NULL,
  austrittsdatum DATE NULL,
  PRIMARY KEY (fk_pers_id),
  CONSTRAINT ck_svn 
    CHECK (svn BETWEEN 1000 AND 9999),
  CONSTRAINT fk_mitarbeiter_personen
    FOREIGN KEY (fk_pers_id)
    REFERENCES personen (pers_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
;


-- -----------------------------------------------------
-- Table rechnungen
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS rechnungen (
  rechn_nr SERIAL NOT NULL,
  datum DATE NOT NULL,
  uhrzeit TIME NOT NULL,
  fk_f_id INT NOT NULL,
  fk_kunden_pers_id INT NULL,
  fk_mitarbeiter_pers_id INT NULL,
  PRIMARY KEY (rechn_nr),
  CONSTRAINT fk_rechnungen_filialen
    FOREIGN KEY (fk_f_id)
    REFERENCES filialen (f_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT fk_rechnungen_kunden
    FOREIGN KEY (fk_kunden_pers_id)
    REFERENCES kunden (fk_pers_id)
    ON DELETE SET NULL
    ON UPDATE SET NULL,
  CONSTRAINT fk_rechnungen_mitarbeiter
    FOREIGN KEY (fk_mitarbeiter_pers_id)
    REFERENCES mitarbeiter (fk_pers_id)
    ON DELETE SET NULL
    ON UPDATE SET NULL)
;


-- -----------------------------------------------------
-- Table produkte
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS produkte (
  produkt_id SERIAL NOT NULL,
  name VARCHAR(64) NOT NULL,
  preis REAL NOT NULL,
  mwst REAL NOT NULL,
  ausgelaufen BOOLEAN NOT NULL DEFAULT FALSE,
  PRIMARY KEY (produkt_id))
;


-- -----------------------------------------------------
-- Table rechn_prod
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS rechn_prod (
  id SERIAL NOT NULL,
  preis REAL NOT NULL,
  mwst REAL NOT NULL,
  fk_prod_id INT NULL,
  fk_rechn_nr INT NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_rechn_prod_rechnungen
    FOREIGN KEY (fk_rechn_nr)
    REFERENCES rechnungen (rechn_nr)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_rechn_prod_produkte
    FOREIGN KEY (fk_prod_id)
    REFERENCES produkte (produkt_id)
    ON DELETE SET NULL
    ON UPDATE SET NULL)
;


-- -----------------------------------------------------
-- Table allergene
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS allergene (
  kuerzel CHAR(1) NOT NULL,
  bezeichnung VARCHAR(64) NOT NULL,
  PRIMARY KEY (kuerzel),
  CONSTRAINT ck_kuerzel 
	CHECK (kuerzel in ('A','B','C','D','E','F','G','H','L','M','N','O','P','R')))
;


-- -----------------------------------------------------
-- Table allerg_prod
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS allerg_prod (
  fk_kuerzel CHAR(1) NOT NULL,
  fk_produkt_id INT NOT NULL,
  PRIMARY KEY (fk_kuerzel, fk_produkt_id),
  CONSTRAINT fk_allerg_prod_allergene1
    FOREIGN KEY (fk_kuerzel)
    REFERENCES allergene (kuerzel)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_allerg_prod_produkte
    FOREIGN KEY (fk_produkt_id)
    REFERENCES produkte (produkt_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
;


COMMIT;

