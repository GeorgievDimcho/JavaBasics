/*
 * This script demonstrates how transactions use locks, commits, and rollbacks
 * Session 2
 */
 
 
 --PROMPT
--PROMPT
--PROMPT ** update table person
--PROMPT

-- update record 1
LOCK TABLE person IN ROW SHARE MODE;


-- update record 2
LOCK TABLE person IN EXCLUSIVE MODE;


--PROMPT
--PROMPT
--PROMPT ** change to session 1, rollback and execute select
--PROMPT



ROLLBACK;
