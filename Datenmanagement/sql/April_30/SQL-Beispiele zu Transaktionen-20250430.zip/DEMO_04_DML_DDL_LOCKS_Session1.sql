/*
 * This script demonstrates how transactions use locks, commits, and rollbacks
 * Session 1
 */
 
--PROMPT
--PROMPT
--PROMPT ** create tabel person1
--PROMPT

CREATE TABLE person1 AS SELECT * FROM person;
 

SELECT * FROM person1
WHERE personid = 1;





--PROMPT
--PROMPT
--PROMPT ** Start a transaction in SESSION 1 by running an update statement
--PROMPT

UPDATE person1
SET vorname = 'Ronald'
WHERE personid = 1;





--PROMPT
--PROMPT
--PROMPT ** START ANOTHER SQL*PLUS SESSION AND try to drop table person
--PROMPT


ROLLBACK;

