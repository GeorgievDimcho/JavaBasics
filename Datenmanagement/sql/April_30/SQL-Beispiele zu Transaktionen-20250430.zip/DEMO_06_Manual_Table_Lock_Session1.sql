/*
 * This script demonstrates how transactions use locks, commits, and rollbacks
 * Session 1
 */


--PROMPT
--PROMPT
--PROMPT ** set manual row lock with for update statement
--PROMPT

SELECT *
FROM person
WHERE personid = 2 FOR UPDATE;





--PROMPT
--PROMPT
--PROMPT ** START ANOTHER SQL*PLUS SESSION AND try to update table person
--PROMPT


ROLLBACK;



