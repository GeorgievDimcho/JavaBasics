/*
 * This script demonstrates how transactions use locks, commits, and rollbacks
 * Session 2
 */
 
 
--PROMPT
--PROMPT
--PROMPT ** drop table person
--PROMPT

SELECT * FROM person1;

DROP TABLE person1;

ROLLBACK;
