/*
 * LockSession2.sql
 * see Chapter 4, Oracle10g PL/SQL Programming
 *
 * This script demonstrates how transactions use locks, commits, and rollbacks
 * This script is for the second session as noted in the book.
 */


--PROMPT
--PROMPT
--PROMPT ** Query the AUTHORS table to see if the change from session 1 can be seen
--PROMPT

SELECT * 
FROM person
WHERE personid = 1;

--PROMPT
--PROMPT
--PROMPT ** Try updating the same record from this session - IT SHOULD HANG
--PROMPT

UPDATE person
SET vorname = 'Ronald'
WHERE personid = 1;



SELECT * 
FROM person
WHERE personid = 1;


ROLLBACK;
