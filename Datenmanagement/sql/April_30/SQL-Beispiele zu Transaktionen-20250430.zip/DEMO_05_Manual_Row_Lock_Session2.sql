/*
 * This script demonstrates how transactions use locks, commits, and rollbacks
 * Session 2
 */
 
 
 --PROMPT
--PROMPT
--PROMPT ** update table person
--PROMPT

-- update record 1
UPDATE person
SET vorname = 'Ronald'
WHERE personid = 1;


-- update record 2
UPDATE person
SET vorname = 'Ronny'
WHERE personid = 2;


SELECT *
FROM person
WHERE personid IN (1,2);

ROLLBACK;

