/*
 * This script demonstrates how transactions use locks, commits, and rollbacks
 * Session 2
 */


--PROMPT
--PROMPT
--PROMPT ** update statement 1
--PROMPT

UPDATE person
SET vorname = 'Chris'
WHERE personid = 2;

--PROMPT
--PROMPT
--PROMPT ** START ANOTHER SQL*PLUS SESSION AND try to update table person
--PROMPT

--PROMPT
--PROMPT
--PROMPT ** update statement 2
--PROMPT

UPDATE person
SET vorname = 'Harri'
WHERE personid = 1;

--PROMPT
--PROMPT
--PROMPT ** START ANOTHER SQL*PLUS SESSION AND try to update table person
--PROMPT


ROLLBACK;



select * from person
where personid in (1,2);

