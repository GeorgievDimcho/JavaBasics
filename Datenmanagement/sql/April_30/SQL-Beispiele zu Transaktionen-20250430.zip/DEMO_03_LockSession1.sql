/*
 * LockSession1.sql
 * see Chapter 4, Oracle10g PL/SQL Programming
 *
 * This script demonstrates how transactions use locks, commits, and rollbacks
 */

SELECT * FROM person
WHERE personid = 1;


--PROMPT
--PROMPT
--PROMPT ** Start a transaction in SESSION 1 by running an update statement
--PROMPT

UPDATE person
SET vorname = 'Ronald'
WHERE personid = 1;

--PROMPT
--PROMPT
--PROMPT ** Check for locks held after starting the transaction
--PROMPT

SELECT d.session_id sid, d.lock_type, d.mode_requested,
       d.mode_held, d.blocking_others
FROM dba_locks d, v$session v
WHERE v.username = 'SYS'
AND d.session_id = v.sid
ORDER BY sid;


--PROMPT
--PROMPT
--PROMPT ** Get the name and type of object locked
--PROMPT

SELECT dbl.session_id sid, dbl.lock_type, dbl.mode_held, dbl.blocking_others, 
       dbo.object_name object_locked, dbo.object_type
FROM dba_locks dbl, v$session v, dba_objects dbo
WHERE v.username = 'SYS'
AND dbl.session_id = v.sid
AND dbo.object_id = dbl.lock_id1
ORDER BY 1;

--PROMPT
--PROMPT
--PROMPT ** START ANOTHER SQL*PLUS SESSION AND RUN LockSession2.sql
--PROMPT

/* 
Run this select after the second session is hung.  This select statement will show the transaction lock for the second session in queue
*/
SELECT d.session_id sid, d.lock_type, d.mode_requested,
       d.mode_held, d.blocking_others
FROM dba_locks d, v$session v
WHERE v.username = 'SYS'
AND d.session_id = v.sid;




SELECT * FROM person
WHERE personid = 1;


-- commit or rollback
ROLLBACK;

