/* ---------------------------
-- (1) Rechnungsdaten einfügen
*/ ---------------------------


/* ---------------------------------------
-- Rechnung 1 - Rasthofen - Daten einfügen
*/ ---------------------------------------
insert all
	into orte values (9999, 'Rasthofen')
	into adressen values (1, 'Strudelweg', '1', 9999)
	into filialen values (1, 'ATU123456789', 'Rasthofen', '+43 (0)999 / 1111', 'DW 12', 1, '0')
	
	into orte values (1010, 'Wien')
	into adressen values (4, 'Kärntnerstraße', '5', 1010)
	into personen values (1, 'Max', 'Mustermax', 'm', 4)
	into kunden values (1, 1)
	
	into personen values (2, null, 'Flott', 'w', null)
	into mitarbeiter values (2, 1, 1001, to_date('23.10.1990', 'dd.mm.yyyy'), to_date('01.05.2008', 'dd.mm.yyyy'), null)
	
	into rechnungen values (3334569, to_date('01.09.2008 12:47', 'dd.mm.yyyy hh24:mi'), to_date('01.09.2008 12:47', 'dd.mm.yyyy hh24:mi'), 1, 1, 2)
	
	into produkte values (1, 'Cappuccino', 2.9, 20, 0)
	into produkte values (2, 'Himbertörtchen', 3.1, 10, 1)
	into produkte values (3, 'Cola 0,3', 2.5, 20, 0)
	into produkte values (4, 'Wienerschnitzel mit Pommes', 9.9, 10, 0)
	into produkte values (5, 'Wurstsemmel', 2.2, 10, 0)
	
	into rechn_prod values (1, 2.9, 20, 1, 3334569)
	into rechn_prod values (2, 3.1, 10, 2, 3334569)
	into rechn_prod values (3, 2.5, 20, 3, 3334569)
	into rechn_prod values (4, 2.9, 20, 1, 3334569)
	into rechn_prod values (5, 9.9, 10, 4, 3334569)
	into rechn_prod values (6, 2.2, 10, 5, 3334569)
	
	select * from dual;


/* ----------------------------------------
-- Rechnung 2 - Pausendorf - Daten einfügen
*/ ----------------------------------------
insert all
	into orte values (8888, 'Pausendorf')
	into adressen values (2, 'Moststraße', '7', 8888)
	into filialen values (2, 'ATU123456789', 'Pausendorf', '+43 (0)888 / 2222', 'DW 23', 2, '0')
	
	into orte values (1020, 'Wien')
	into adressen values (5, 'Obere Augartenstraße', '66', 1020)
	into personen values (3, 'Carina', 'Sidon', 'w', 5)
	into kunden values (3, 2)
	
	into personen values (4, null, 'Schnell', 'm', null)
	into mitarbeiter values (4, 2, 2002, to_date('12.04.1985', 'dd.mm.yyyy'), to_date('01.03.2005', 'dd.mm.yyyy'), null)
	
	into rechnungen values (22234568, to_date('05.11.2009 21:34', 'dd.mm.yyyy hh24:mi'), to_date('05.11.2009 21:34', 'dd.mm.yyyy hh24:mi'), 2, 3, 4)
	
	into produkte values (6, 'Fanta 0,25', 2.9, 20, 0)
	into produkte values (7, 'Schinkenkäsetoast', 3.5, 10, 0)
	into produkte values (8, 'Sachertorte', 3.2, 10, 0)
	into produkte values (9, 'Melange', 2.9, 20, 0)
	
	into rechn_prod values (7, 2.9, 20, 6, 22234568)
	into rechn_prod values (8, 3.5, 10, 7, 22234568)
	into rechn_prod values (9, 3.2, 10, 8, 22234568)
	into rechn_prod values (10, 2.9, 20, 9, 22234568)
	
	select * from dual;



/* ---------------------------------------
-- Rechnung 3 - Haltern - Daten einfügen
*/ ---------------------------------------
insert all
	into orte values (7777, 'Haltern')
	into adressen values (3, 'Rastweg', '1', 7777)
	into filialen values (3, 'ATU123456789', 'Haltern', '+43 (0)777 / 3333', 'DW 77', 3, '0')
	
	into personen values (5, null, 'Gschwind', 'w', null)
	into mitarbeiter values (5, 3, 3003, to_date('08.07.1988', 'dd.mm.yyyy'), to_date('01.08.2008', 'dd.mm.yyyy'), null)
	
	into rechnungen values (11123457, to_date('01.08.2009 18:53', 'dd.mm.yyyy hh24:mi'), to_date('01.08.2009 18:53', 'dd.mm.yyyy hh24:mi'), 3, null, 5)
	
	into produkte values (10, 'Bier 0,5', 3.8, 20, 0)
	
	into rechn_prod values (11, 3.8, 20, 10, 11123457)
	
	select * from dual;


-- Eingaben bestätigen
commit;





/* ---------------------------------------
-- (2) alle Daten von Carina Sidon löschen
--     Rechungen müssen erhalten beleiben
*/ ---------------------------------------
-- relevante Tabellen prüfen
select * from personen;
select * from kunden;
select * from rechnungen;
select * from adressen;


-- Beziehung zu Rechnung löschen
update rechnungen
  set fk_kunden_pers_id = null
  where fk_kunden_pers_id = 3;

-- Daten aus Tabelle Kunden löschen
delete from kunden
  where fk_pers_id = 3;

-- Daten aus Tabelle Personen löschen
delete from personen
  where pers_id = 3;

-- Daten aus Tabelle Adressen löschen
delete from adressen
  where addr_id = 5;


-- Änderungen überprüfen
select * from personen;
select * from kunden;
select * from rechnungen;
select * from adressen;

-- Änderungen bestätigen
commit;





/* --------------------------------------
-- (3) Rechnung 3 Herr Mustermax zuordnen
*/ --------------------------------------
-- relevante Tabellen ausgeben
select * from rechnungen;
select * from personen;
select * from kunden;


-- Rechnung zuordnen
update rechnungen
  set fk_kunden_pers_id = 1
  where rechn_nr = 11123457;


-- Änderung überprüfen
select * from rechnungen;

-- Änderung bestätigen
commit;

