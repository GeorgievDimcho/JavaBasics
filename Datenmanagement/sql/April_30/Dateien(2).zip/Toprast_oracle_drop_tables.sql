-- drop TOPRASRT tables
drop table allerg_prod cascade constraints;
drop table allergene cascade constraints;
drop table rechn_prod cascade constraints;
drop table produkte cascade constraints;
drop table rechnungen cascade constraints;
drop table filialen cascade constraints;
drop table kunden cascade constraints;
drop table mitarbeiter cascade constraints;
drop table personen cascade constraints;
drop table adressen cascade constraints;
drop table orte cascade constraints;
